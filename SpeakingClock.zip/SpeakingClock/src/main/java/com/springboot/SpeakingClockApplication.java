package com.springboot;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeakingClockApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeakingClockApplication.class, args);
		
		
        String words[] = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen",
            "Sixteen","Seventeen","Eighteen","Nineteen","Twenty","Twenty one","Twenty two","Twenty three","Twenty four","Twenty five","Twenty six",
            "Twenty seven","Twenty eight", "Twenty nine","Thirty","Thirty one","Thirty two","Thirty three","Thirty four","Thirty five","Thirty six",
            "Thirty seven","Thirty eight", "Thirty nine","Fourty","Fourty one","Fourty two","Fourty three","Fourty four","Fourty five","Fourty six",
            "Fourty seven","Fourty eight", "Fourty nine","Fivety","Fivety one","Fivety two","Fivety three","Fivety four","Fivety five","Fivety six",
            "Fivety seven","Fivety eight", "Fivety nine"};
				
        
        DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("hh:mm a");
    	String localTimeString = FOMATTER.format( LocalTime.now() );
    	int hour=LocalTime.now().getHour();
    	int minute=LocalTime.now().getMinute();
    	System.out.println(localTimeString);
    	
    	
    	if(localTimeString.contains("am") && hour==12) {
    		System.out.println("It's Midnight");
    	}
    	else if(localTimeString.contains("pm") && hour==12) {
    		System.out.println("It's Midday");
    	}
    	else {System.out.println("It's "+words[hour]+" "+words[minute]);}
						
		
	}

}
