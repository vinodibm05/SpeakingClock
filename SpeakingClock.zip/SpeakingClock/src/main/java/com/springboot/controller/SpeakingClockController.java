package com.springboot.controller;

import java.util.List;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.model.ClockTime;
import com.springboot.service.ClockTimeService;

@Controller
public class SpeakingClockController {

	private static final Logger logger = (Logger) LogManager.getLogger(SpeakingClockController.class);

	
	@Autowired
	private ClockTimeService service;
	
	@GetMapping("/home")
	public String home(Model model,HttpServletRequest request) {
		logger.info("Welcome !!");
		Scanner in = new Scanner(System.in);
        int hr, min;
        String words[] = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen",
            "Sixteen","Seventeen","Eighteen","Nineteen","Twenty","Twenty one","Twenty two","Twenty three","Twenty four","Twenty five","Twenty six",
            "Twenty seven","Twenty eight", "Twenty nine","Thirty","Thirty one","Thirty two","Thirty three","Thirty four","Thirty five","Thirty six",
            "Thirty seven","Thirty eight", "Thirty nine","Fourty","Fourty one","Fourty two","Fourty three","Fourty four","Fourty five","Fourty six",
            "Fourty seven","Fourty eight", "Fourty nine","Fivety","Fivety one","Fivety two","Fivety three","Fivety four","Fivety five","Fivety six",
            "Fivety seven","Fivety eight", "Fivety nine"};
		
        
        
        
        //  logger.info("Enter Hour"); 
		//  hr = in.nextInt();
		  //logger.info("Enter Minutes"); 
		 //  min = in.nextInt();
		 // logger.info("It's "+words[hr]+" "+words[min]);	
		  
        
          model.addAttribute("hours","hours");
		  model.addAttribute("minutes","minutes");
        
		  return "home";
	}
	
	@PostMapping(value="/saveDetails")
	public String home(HttpServletRequest request) {
		logger.info("saveDetails---");
	     
	    return "welcome";
	}
	
	

	@PostMapping(value = "/save")
	public ClockTime saveTime(@RequestBody ClockTime times) {
				
		return service.addTime(times);
	}

	@GetMapping("/getTimes")
	public List<ClockTime> findAllTimes() {
		return service.getTimes();
	}
	
	
	
	
}
