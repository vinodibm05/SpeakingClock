package com.springboot.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Id;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "clockTime")
public class ClockTime {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
public int id;
public int hours;
public int minutes;


public ClockTime(int id, int hours, int minutes) {
	super();
	this.id = id;
	this.hours = hours;
	this.minutes = minutes;
}


public ClockTime() {
	// TODO Auto-generated constructor stub
}


}
