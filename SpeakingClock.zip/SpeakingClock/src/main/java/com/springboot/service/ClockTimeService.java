package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.model.ClockTime;
import com.springboot.repository.ClockRepository;

@Service
public class ClockTimeService {

	
	
	@Autowired
	private ClockRepository repository;
	

	public ClockTime addTime(ClockTime time) {
		return repository.save(time);
	}

	public List<ClockTime> getTimes() {
		List<ClockTime> times = repository.findAll();
		System.out.println("Getting Time from DB : " + times);
		return times;
	}

}
