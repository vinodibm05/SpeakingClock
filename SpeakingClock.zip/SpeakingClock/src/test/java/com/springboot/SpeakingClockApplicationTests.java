package com.springboot;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.springboot.model.ClockTime;
import com.springboot.repository.ClockRepository;
import com.springboot.service.ClockTimeService;


@RunWith(SpringRunner.class)
@SpringBootTest
class SpeakingClockApplicationTests {

	
	@Autowired
	private ClockTimeService service;

	@MockBean
	private ClockRepository repository;

	
	@Test
	void contextLoads() {
	}

	
	@Test
	public void saveTimeTest() {
		ClockTime time = new ClockTime(32,13,33);
		when(repository.save(time)).thenReturn(time);
		assertEquals(time, service.addTime(time));
	}

	@Test
	public void getTimesTest() {
		when(repository.findAll()).thenReturn(Stream
				.of(new ClockTime(33, 22,33), new ClockTime(34, 11, 35)).collect(Collectors.toList()));
		assertEquals(2, service.getTimes().size());
	}
	
	
	
}
